console.log('ia_kwl.js')
console.log("versão 7-2-2023")

enviar_para_background_js("OFF")

function enviar_para_background_js(mensagem_para_o_background) {

    //envia mensagem para o background.js
    //chrome.runtime.sendMessage(chave+valor_a_ser_salvo);
    chrome.runtime.sendMessage(mensagem_para_o_background, function (response) {
        console.log("\r\n\r\n\r\nia_kwl.js diz: recebemos do background a seguinte resposta: '" + response + "'\r\n\r\n\r\n")
        //retornar a resposta do background
        if (response.includes("#resposta_da_busca#")) {
            //se cairmos aqui significa que recebemos a resposta da busca
        }
    });
}









    function numero_aleatorio(numero_inicial, numero_limite) {
        return Math.floor(Math.random() * (numero_inicial - numero_limite)) + numero_limite;
    }

    document.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            enviar()
        }
    });
    let contexto_da_conversa = ""
    function enviar() {
        try {

            function pergunta_pra_outra_ia(pergunta_) {



                let pergunta = pergunta_.replace(" ", "%20")

                fetch("https://you.com/api/streamingSearch?q=" + pergunta +
                        "&page=1&count=10&safeSearch=Moderate&onShoppingPage=false&mkt=&responseFilter=WebPages,Translations,TimeZone,Computation,RelatedSearches&domain=youchat&queryTraceId=8b945f58-9587-4bf0-b3d6-621e8f299b30&chat=%5B%5D&chatId=8b945f58-9587-4bf0-b3d6-621e8f299b30", {
                            "headers": {
                                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36",
                                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                                "Accept-Encoding": "gzip, deflate, br",
                                "Accept-Language": "en-US,en;q=0.5"

                            },
                            "body": null
                        }).then(response => {
                        return response.text();
                    })
                    .then(data => {
                        console.log(typeof (data))
                        console.log(data)


                        // let resposta_final_da_ia = ((decodeUnicode(result)).replaceAll("donedata: I'm Mr. Meeseeks. Look at me.", '')).replace("event:", "");
                        let resposta_final_da_ia = data
                            .split('\n')
                            .filter(s => s.includes('data:'))
                            .map(s => s.replace('data: ', ''))
                            .map(s => decodeURIComponent(s))
                            .filter(s => s.includes('youChatToken'))
                            .map(JSON.parse)
                            .map(s => s.youChatToken)
                            .join('')
                            .replaceAll('```', '\n')
                            .replaceAll('. ', '\n')
                            .trim();                    

                        let ul = document.querySelector('.ul-lista-de-conversa');
                        let li = document.createElement('li');
                        li.setAttribute('class', 'resposta-bot');
                        let pre = document.createElement("pre")
                        pre.innerHTML = resposta_final_da_ia
                        li.appendChild(pre)
                        ul.appendChild(li);
                        rolar_para_ultimo_elemento_da_lista()
                        
                        
                    });





            }

    
      



        } catch (error) {
            console.log(`erro ao buscar siginificado "${error}"`)
        }
        try {
            let entrada_do_usuario = document.querySelector("#entrada-do-usuario").value;
            let ul = document.querySelector('.ul-lista-de-conversa');
            let li = document.createElement('li');
            li.setAttribute('class', 'entrada_usuario');
            let text = document.createTextNode(entrada_do_usuario);
            li.appendChild(text);
            ul.appendChild(li);
            document.querySelector("#entrada-do-usuario").value = "";
            contexto_da_conversa += document.querySelector('ul li:last-child').textContent;
            if(contexto_da_conversa == "Oi, como posso ajudar?" ){
                contexto_da_conversa = ""
            }
            pergunta_pra_outra_ia("responda em portugues. "+contexto_da_conversa+""+entrada_do_usuario+"?")
        } catch (error) {
            console.log(`erro no enviar "${error}"`)
        }
    }



function rolar_para_ultimo_elemento_da_lista(){
    try {
        document.querySelector("#resultado").scrollTop += 10;
    } catch (error) {
        console.log(`erro ao rolarar para ultimo elemento da lista "${error}"`)
    }
}